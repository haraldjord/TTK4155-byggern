# TTK4155-byggern
Embedded code for a ping pong playing machine

How to download git: https://www.qamadness.com/knowledge-base/how-to-install-git-and-clone-a-repository/
